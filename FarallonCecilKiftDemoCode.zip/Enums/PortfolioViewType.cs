﻿namespace Farallon.Enums
{
    public enum PortfolioViewType
    {
        Trades,
        ProfitAndLoss
    }
}