﻿namespace Farallon.Enums
{
    public enum TradeAction
    {
        Buy,
        Sell
    }
}