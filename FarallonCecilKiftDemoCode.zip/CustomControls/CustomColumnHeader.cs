﻿using System.Windows.Forms;

namespace Farallon.CustomControls
{
    public class CustomColumnHeader : ColumnHeader
    {
        public int MinimumWidth { get; set; }
    }
}