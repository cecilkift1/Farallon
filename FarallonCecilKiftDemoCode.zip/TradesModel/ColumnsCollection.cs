﻿using System.Collections.Generic;
using Farallon.Interfaces;

namespace Farallon
{
    public class ColumnsCollection
    {
        protected IList<IColumn> _columns;
    }
}